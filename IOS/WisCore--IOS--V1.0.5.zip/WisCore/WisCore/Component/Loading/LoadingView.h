//
//  LoadingView.h
//  smartdrone
//
//  Created by liweixiang on 15-4-28.
//  Copyright (c) 2015年 rak. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoadingView : UIView

- (void)setLoadingShow:(BOOL)isShow :(NSString*)str;
- (void)setLoadingText:(NSString*)str;
@end
