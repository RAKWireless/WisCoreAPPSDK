//
//  Lx52x_Device_Info.h
//
//
//  Created by 韦伟 on 15/5/14.
//  Copyright (c) 2015年 rakwireless. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Lx52x_Device_Info : NSObject

@property int Device_Number;
@property NSArray* Device_IP_Arr;
@property NSArray* Device_ID_Arr;
@end
